CREATE VIEW `v_score` AS
  SELECT
    `examweb`.`course`.`cname` AS `cname`,
    `examweb`.`score`.`sid`    AS `sid`,
    `examweb`.`score`.`score`  AS `score`,
    `examweb`.`score`.`cid`    AS `cid`
  FROM (`examweb`.`score`
    JOIN `examweb`.`course` ON ((`examweb`.`score`.`cid` = `examweb`.`course`.`cid`)))